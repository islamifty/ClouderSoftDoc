<div class="preloader" id="preloader">
    <div class="preloader-inner">
        <div></div>
        <hr/>
    </div>
</div>
